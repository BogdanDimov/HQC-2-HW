﻿public abstract class Exam
{
    public abstract ExamResult CalculateResult();
}
