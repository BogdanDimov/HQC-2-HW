﻿  
  
  
// This is generated code:  
class MyGeneratedClass {  
  
  // Generated code:  
  private int P1 = 0;  
  
  // Generated code:  
  private int P2 = 0;  
  
  // Generated code:  
  private int P3 = 0;  
  
}  