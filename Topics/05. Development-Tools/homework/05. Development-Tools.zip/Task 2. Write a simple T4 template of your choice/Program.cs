﻿namespace T4Templates
{
    public class Program
    {
        public static void Main()
        {
            
        }
    }
}
