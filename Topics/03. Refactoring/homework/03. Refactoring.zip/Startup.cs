﻿namespace TraverseMatrix
{
    using System;

    public class Startup 
    {
        public static void Main()
        {
            Matrix matrix = new Matrix(3);
            Console.WriteLine(matrix);
        }
    }
}
